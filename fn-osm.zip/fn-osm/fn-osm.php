<?php
/*
* Plugin Name: firmennest Leaflet - OpenStreetMap
* Version: 1.0.0
* Plugin URI: https://www.firmennest.de/
* Description: Interaktive Karte mittels Shortcode [fn-osm lat="" lng="" zoom=""]
* Author: nest online GmbH
* Author URI: https://www.firmennest.de/
*/

if (!defined('ABSPATH')) exit;

class fnOSM {
  static $add_assets;

  static function init() {
    add_shortcode('fn-osm', array(__CLASS__, 'handle_shortcode'));
    add_action('init', array(__CLASS__, 'register_assets'));
    add_action('wp_footer', array(__CLASS__, 'print_assets'));
  }

  static function handle_shortcode($atts) {
    self::$add_assets = true;

    ob_start();
    $atts = shortcode_atts(array(
      'lat' => '',
      'lng' => '',
      'zoom' => '13',
    ), $atts, 'fn-osm');

    if (!empty($atts['lat']) && !empty($atts['lng'])) {
      $identifier = rand(1000, 9999);
      ?><div id="fn-osm-<?php echo $identifier; ?>" class="fn-osm-container uk-height-medium uk-width-1-1 uk-position-relative uk-position-z-index"></div>
      <script type="text/javascript">
        var waitForL = function () {
          if (typeof L !== 'undefined') {
            var map = L.map('fn-osm-<?php echo $identifier; ?>', {
              scrollWheelZoom: false,
            }).setView([<?php echo $atts['lat']; ?>, <?php echo $atts['lng']; ?>], <?php echo $atts['zoom']; ?>);
            var tileLayer = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);
            var marker = L.marker([<?php echo $atts['lat']; ?>, <?php echo $atts['lng']; ?>]).addTo(map);
          } else {
            window.setTimeout(waitForL, 300);
          }
        };
        window.setTimeout(waitForL, 300);
      </script><?php
    }

    return ob_get_clean();
  }

  static function register_assets() {
    wp_register_style('fn-osm-leaflet', plugins_url('assets/css/leaflet.css', __FILE__), array(), '1.9.2', 'all');
    wp_register_script('fn-osm-leaflet', plugins_url('assets/js/leaflet.js', __FILE__), array(), '1.9.2', true);
  }

  static function print_assets() {
    if (!self::$add_assets)
      return;
    wp_print_styles('fn-osm-leaflet');
    wp_print_scripts('fn-osm-leaflet');
  }
}

fnOSM::init();
